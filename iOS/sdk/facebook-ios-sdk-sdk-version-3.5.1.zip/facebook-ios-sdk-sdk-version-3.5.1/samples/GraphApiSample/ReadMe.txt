Graph Api sample

Demonstrates the basics of how to make a singleton or batch request using the Facebook SDK for IOS.

Using the Sample
Install the Facebook SDK for iOS.
Launch the GraphApiSample project using Xcode from the <Facebook SDK>/samples/GraphApiSample directory.
