Profile Picture Control sample

Demonstrates how to use the Profile picture control provided with 
the Facebook SDK for iOS.

Using the Sample
Install the Facebook SDK for iOS.
Launch the ProfilePictureSample project using Xcode from the <Facebook SDK>/samples/ProfilePictureSample directory.
